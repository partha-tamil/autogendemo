# app.py
import json
import os,autogen
import asyncio
from flask import Flask, request, jsonify
from flask_cors import CORS # Needed to allow requests from your web app (different origin)
from autogenstudio import WorkflowManager
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from openai import AzureOpenAI

app = Flask(__name__)
CORS(app) # Enable Cross-Origin Resource Sharing

# Define the path for the chat history file
CHAT_HISTORY_FILE = "autogen_chat_history.json"

#LLM Configuration
llm_config = {
"model": "gpt-4",
"api_type": "azure",
"api_version": "2025-01-01-preview",
"base_url": "https://autogenpoc.openai.azure.com/",
"api_key":"4FeRiB2mp2Ta0kNaoWlRvsBULaUbskLSqszjKQzwLlhuOdQkXU09JQQJ99BFACYeBjFXJ3w3AAABACOGXMW5"
}

def save_chat_history(messages, filename=CHAT_HISTORY_FILE):
    """
    Saves the chat history to a JSON file.
    Args:
        messages (list): A list of message dictionaries from the chat.
        filename (str): The name of the file to save the history to.
    """
    print(f"\n--- Saving chat history to {filename} ---")
    try:
        with open(filename, 'w') as f:
            json.dump(messages, f, indent=4)
        print("Chat history saved successfully.")
    except IOError as e:
        print(f"Error saving chat history: {e}")

def load_chat_history(filename=CHAT_HISTORY_FILE):
    """
    Loads chat history from a JSON file.
    Args:
        filename (str): The name of the file to load the history from.
    Returns:
        list: A list of message dictionaries, or an empty list if the file doesn't exist.
    """
    if os.path.exists(filename):
        print(f"\n--- Loading chat history from {filename} ---")
        try:
            with open(filename, 'r') as f:
                messages = json.load(f)
            print(f"Loaded {len(messages)} messages.")
            return messages
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON from history file: {e}. Starting fresh.")
            return []
        except IOError as e:
            print(f"Error loading chat history: {e}. Starting fresh.")
            return []
    else:
        print(f"No existing chat history found at {filename}. Starting fresh.")
        return []

# --- AutoGen Agents Setup for Multi-Agent Conversation ---

# Global variables to hold agents and manager state
# This is a simplification for a single-user demo. For multi-user,
# you'd manage sessions and agent instances per user.
user_proxy = None
orchestrator = None

# Azure OpenAI Configuration
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT", "https://autogenpoc.openai.azure.com/")
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY", "4FeRiB2mp2Ta0kNaoWlRvsBULaUbskLSqszjKQzwLlhuOdQkXU09JQQJ99BFACYeBjFXJ3w3AAABACOGXMW5")
AZURE_OPENAI_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4") # e.g., "gpt-4" or "gpt-35-turbo"
AZURE_OPENAI_API_VERSION = "2024-02-01" # Or your specific API version

# Azure AI Search Configuration
AZURE_SEARCH_ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT", "https://autogenpoc-search.search.windows.net")
AZURE_SEARCH_API_KEY = os.getenv("AZURE_SEARCH_API_KEY", "DVGDb4y1xxyHIQrHYbje5EYDe3T6sbG6Ra2n3RpRvJAzSeAuP56e")
AZURE_SEARCH_INDEX_NAME = os.getenv("AZURE_SEARCH_INDEX_NAME", "rag-1750581699787")


# --- Initialize Clients ---
try:
    # Initialize Azure OpenAI Client
    openai_client = AzureOpenAI(
        azure_endpoint=AZURE_OPENAI_ENDPOINT,
        api_key=AZURE_OPENAI_API_KEY,
        api_version=AZURE_OPENAI_API_VERSION
    )
    print("Azure OpenAI client initialized successfully.")

    # Initialize Azure AI Search Client
    search_client = SearchClient(
        endpoint=AZURE_SEARCH_ENDPOINT,
        index_name=AZURE_SEARCH_INDEX_NAME,
        credential=AzureKeyCredential(AZURE_SEARCH_API_KEY)
    )
    print("Azure AI Search client initialized successfully.")

except Exception as e:
    print(f"Error initializing clients: {e}")
    print("Please ensure your environment variables/configurations are correct.")
    exit()

def initialize_agents(llm_config):
    """
    Initializes AutoGen agents and the group chat manager.
    Sets them as global variables for persistent access across requests.
    """
    global user_proxy, orchestrator

    if user_proxy is None or orchestrator is None:
        print("Initializing AutoGen agents...")
        # The UserProxyAgent acts as the human and can provide input
        # Set human_input_mode to "NEVER" for web interaction, as we'll feed input via API

    #agent definitions
    user_proxy = autogen.UserProxyAgent(
    name="user_proxy",
    code_execution_config=False,
    is_termination_msg=lambda x: "TERMINATE" in x.get("content", "").upper(),  # Please set use_docker=True if docker is available to run the generated code. Using docker is safer than running the generated code directly.
    human_input_mode="NEVER",
    system_message="You are the human user. Your input comes from the web UI. "
                            "You can provide feedback, approve tax report, or tell the agents to TERMINATE. "
                            "When you send a message, it's considered a new human input.",
    )

data_accumulator_compliance_rules = autogen.AssistantAgent(
    name="data_accumulator_compliance_rules",
    llm_config=llm_config,
    #system_message="You are a data retrieval agent to fetch only tax rules. Your role is to query an Azure AI Search index and fetch the relevant chunk of data based on a given user query.",
    system_message = (
        "You are a helpful AI assistant that answers questions based ONLY on the provided context. "
        "If the answer cannot be found in the context, politely state that you don't have enough information. "
       
    )
)

rules_comparator = autogen.AssistantAgent(
    name="rules_comparator",
    llm_config=llm_config,
    code_execution_config=False,
    #system_message="You are a document comparison agent of tax rules. Retrieve the tax rules stored in shared memory and compare it with the document received from user proxy or input. Your task is to analyze two input documents and identify any differences between them. These may include changes in wording, structure, formatting, data values, or semantic meaning. Highlight both exact (verbatim) differences and subtle contextual shifts. Your output should be structured to indicate the type of difference, location within the document, and a clear explanation of the change. Be concise and accurate, and do not make assumptions beyond the provided content.",
    system_message = (
        "You are a helpful AI assistant that answers questions based ONLY on the provided context. "
        "If the answer cannot be found in the context, politely state that you don't have enough information. "  
    )
)

data_accumulator_judgements = autogen.AssistantAgent(
    name="data_accumulator_judgements",
    llm_config=llm_config,
    #system_message="You are a data retrieval agent to fetch only court orders. Your role is to query an Azure AI Search index and fetch the relevant chunk of data based on a given user query.",
system_message = (
        "You are a helpful AI assistant that answers questions based ONLY on the provided context. "
        "If the answer cannot be found in the context, politely state that you don't have enough information. "
    )
)

judgement_analyzer = autogen.AssistantAgent(
    name="judgement_analyzer",
    llm_config=llm_config,
    code_execution_config=False,
    #system_message="You are a document comparison agent of court orders and prepare a report on deviation of tax compliance. Retrieve the court orders stored in shared memory and compare it with the document received from user proxy or input. Your task is to analyze two input documents and identify any differences between them. These may include changes in wording, structure, formatting, data values, or semantic meaning. Highlight both exact (verbatim) differences and subtle contextual shifts. Your output should be structured to indicate the type of difference, location within the document, and a clear explanation of the change. Be concise and accurate, and do not make assumptions beyond the provided content. Generate a PDF report.",
    system_message = (
        "You are a helpful AI assistant that answers questions based ONLY on the provided context. "
        "If the answer cannot be found in the context, politely state that you don't have enough information. "
       
    )
)

'''prompt_compressor = autogen.AssistantAgent(
    name="prompt compressor",
    llm_config=llm_config,
    system_message="You are AI assitant to compress the data received from AI search to generate input less than 16000 tokens",
)'''

allowed_speaker_transitions = {
    user_proxy: [rules_comparator, judgement_analyzer],
    rules_comparator: [judgement_analyzer, user_proxy],
    judgement_analyzer: [user_proxy, rules_comparator]
}

processor = autogen.GroupChat(agents=[user_proxy, rules_comparator, data_accumulator_compliance_rules, judgement_analyzer,data_accumulator_judgements],
                               messages=[],
                                    max_round=12,
                                
                                )
orchestrator = autogen.GroupChatManager(groupchat=processor, llm_config=llm_config)

# Initialize agents when the Flask app starts
initialize_agents(llm_config)

def retrieve_documents_from_search(query_text: str, top_n: int = 3):
    print(f"\nSearching Azure AI Search for: '{query_text}'...")
    try:
        # Perform a simple search. For more advanced scenarios, consider semantic or vector search.
        search_results = search_client.search(
            search_text=query_text,
            top=top_n,
            include_total_count=True,
            query_type="simple" # Can be "semantic", "vector", "full", etc. depending on your index
            # For semantic search: query_type="semantic", semantic_configuration_name="my-semantic-config"
            # For vector search: vector_queries=[VectorQuery(vector=embedding_of_query, k_nearest_neighbors=5, fields="contentVector")]
        )

        documents = []
        for result in search_results:
            # --- DEBUGGING STEP: Print the entire result object ---
            print(f"  --- Full search result document: {result}")
            # --- END DEBUGGING STEP ---

            # Assuming your documents have a 'content' field and a 'title' or 'id' field
            # Adjust field names based on your Azure AI Search index schema
            # IMPORTANT: Check the printed 'result' object above to find the correct field for your document's main content.
            # It might be 'text', 'main_content', 'description', etc., instead of 'content'.
            doc_content = result.get('chunk', 'No content found') # <--- **UPDATE THIS FIELD NAME IF NECESSARY**
            doc_title = result.get('title', result.get('id', 'Untitled Document')) # <--- UPDATE THIS FIELD NAME IF NECESSARY

            documents.append({
                "title": doc_title,
                "content": doc_content,
                "score": result['@search.score']
            })
            print(f"  - Found document: '{doc_title}' (Score: {result['@search.score']:.2f})")
            if doc_content == 'No content found':
                print(f"    WARNING: Content for '{doc_title}' was not found. Check your index schema for the correct content field name.")
        return documents

    except Exception as e:
        print(f"Error during Azure AI Search retrieval: {e}")
        return []


@app.route('/start_chat',methods=['POST'])
def start_chat():
    data = request.json
    user_message = data.get('message', '')
    # Load previous chat history
    loaded_history = load_chat_history()

    #input_text = data['text']
    
    retrieved_docs = retrieve_documents_from_search(user_message)
    #fetch_data_ai_search(input_text)

    system_message = (
        "You are a helpful AI assistant that answers questions based ONLY on the provided context. "
        "If the answer cannot be found in the context, politely state that you don't have enough information. "
    )
   
   
# Format the retrieved documents as context for the LLM
    context_text = ""
    if retrieved_docs:
        context_text = "Context Documents:\n"
        for i, doc in enumerate(retrieved_docs):
            context_text += f"Document {i+1} (Title: {doc['title']}):\n{doc['content']}\n\n"
    else:
        context_text = "No relevant documents were found to provide context.\n\n"

    # Combine context and user query
    full_prompt = f"{context_text}User Question: {user_message}"

    # run the workflow on a task
    
    chat_result = user_proxy.initiate_chat(
    orchestrator, message = full_prompt, 
    summary_method="reflection_with_llm",
    summary_prompt = system_message,
    clear_history= False,
    chat_history = loaded_history
    )
    
     # The chat_history attribute of the chat_result object contains all messages from this conversation
    # (including the loaded history and the new exchanges).
    all_messages = chat_result.chat_history

    # Save the updated chat history for the next session
    save_chat_history(all_messages)


     # Return the messages and summary
    return jsonify({
            'history': [msg for msg in all_messages if isinstance(msg, dict)], # Ensure dict type for JSON serialization
            'summary': chat_result.summary,
            'status': 'completed'
        })


@app.route('/reset_chat', methods=['POST'])
def reset_chat():
    """Resets the chat history file."""
    try:
        if os.path.exists(CHAT_HISTORY_FILE):
            os.remove(CHAT_HISTORY_FILE)
            print(f"Chat history file '{CHAT_HISTORY_FILE}' deleted.")
        # Re-initialize agents to clear any in-memory state as well
        global user_proxy, orchestrator
        user_proxy = None
        orchestrator = None
        initialize_agents(llm_config) # Re-create agents fresh
        return jsonify({'message': 'Chat history reset successfully'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Run the Flask app on port 5000 (or any other available port)
 app.run(debug=True, port=5000)
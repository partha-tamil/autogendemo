# Import necessary autogen modules
import autogen
import requests # Used for making HTTP requests to Azure AI Search
import json # Used for handling JSON responses
import os
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential

# Define the configuration for the Language Model
# Replace "YOUR_GEMINI_API_KEY" with your actual Gemini API key if you want to run this locally.
# For Canvas environment, leave it as an empty string, Canvas will provide it.
llm_config = {
"model": "gpt-4",
"api_type": "azure",
"api_version": "2025-01-01-preview",
"base_url": "https://autogenpoc.openai.azure.com/",
"api_key":"4FeRiB2mp2Ta0kNaoWlRvsBULaUbskLSqszjKQzwLlhuOdQkXU09JQQJ99BFACYeBjFXJ3w3AAABACOGXMW5"
}
# --- Azure AI Search Configuration ---
# IMPORTANT: Replace these with your actual Azure AI Search service details.
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT", "https://autogenpoc.openai.azure.com/")
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY", "4FeRiB2mp2Ta0kNaoWlRvsBULaUbskLSqszjKQzwLlhuOdQkXU09JQQJ99BFACYeBjFXJ3w3AAABACOGXMW5")
AZURE_OPENAI_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4") # e.g., "gpt-4" or "gpt-35-turbo"
AZURE_OPENAI_API_VERSION = "2024-02-01" # Or your specific API version

# Azure AI Search Configuration
AZURE_SEARCH_ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT", "https://autogenpoc-search.search.windows.net")
AZURE_SEARCH_API_KEY = os.getenv("AZURE_SEARCH_API_KEY", "DVGDb4y1xxyHIQrHYbje5EYDe3T6sbG6Ra2n3RpRvJAzSeAuP56e")
AZURE_SEARCH_INDEX_NAME = os.getenv("AZURE_SEARCH_INDEX_NAME", "rag-1750581699787")

assistant = autogen.AssistantAgent(
    name="assistant",
    llm_config=llm_config,
    system_message="""You are a helpful AI assistant. Your primary goal is to provide accurate and concise information.
    When a user asks for information that requires searching, you should suggest using the 'azure_ai_search' tool.
    Once the search results are provided by the user_proxy, synthesize the information and present it clearly.
    If you need to perform a search, clearly state what you want to search for.
    """,
)

# Create a UserProxyAgent. This agent acts on behalf of the user and can execute code.
# It's configured to automatically reply and use the azure_ai_search tool.
user_proxy = autogen.UserProxyAgent(
    name="user_proxy",
    human_input_mode="NEVER",  # Set to "ALWAYS" if you want to provide manual input
    max_consecutive_auto_reply=10, # Max number of consecutive auto-replies
    is_termination_msg=lambda x: x.get("content", "") and x.get("content", "").rstrip().endswith("TERMINATE"),
    code_execution_config={
        "work_dir": "coding", # Directory for code execution
        "use_docker": False,  # Set to True if you want to use Docker for isolation
    },
    llm_config=llm_config, # User proxy can also use LLM for generating replies
    system_message="""You are a user proxy agent. You can execute code and tools on behalf of the user.
    You have access to the 'azure_ai_search' tool.
    When the assistant asks for a search, you will use the 'azure_ai_search' tool to fetch the content.
    After executing a tool, you must provide the output back to the assistant.
    Always end your response with 'TERMINATE' when the task is complete.
    """,
)

# Register the azure_ai_search tool with the user_proxy agent.
# This makes the 'azure_ai_search' function available for the agent to call.
@user_proxy.register_for_execution()
@assistant.register_for_llm(description="A tool for performing searches using Azure AI Search to fetch relevant content.")
def retrieve_documents_from_search(query_text: str, top_n: int = 3):
        print(f"\nSearching Azure AI Search for: '{query_text}'...")
   
        search_client = SearchClient(
        endpoint=AZURE_SEARCH_ENDPOINT,
        index_name=AZURE_SEARCH_INDEX_NAME,
        credential=AzureKeyCredential(AZURE_SEARCH_API_KEY)
        )
        # Perform a simple search. For more advanced scenarios, consider semantic or vector search.
        search_results = search_client.search(
            search_text=query_text,
            top=top_n,
            include_total_count=True,
            query_type="simple" # Can be "semantic", "vector", "full", etc. depending on your index
            # For semantic search: query_type="semantic", semantic_configuration_name="my-semantic-config"
            # For vector search: vector_queries=[VectorQuery(vector=embedding_of_query, k_nearest_neighbors=5, fields="contentVector")]
        )

        documents = []
        for result in search_results:
            # --- DEBUGGING STEP: Print the entire result object ---
            print(f"  --- Full search result document: {result}")
            # --- END DEBUGGING STEP ---

            # Assuming your documents have a 'content' field and a 'title' or 'id' field
            # Adjust field names based on your Azure AI Search index schema
            # IMPORTANT: Check the printed 'result' object above to find the correct field for your document's main content.
            # It might be 'text', 'main_content', 'description', etc., instead of 'content'.
            doc_content = result.get('chunk', 'No content found') # <--- **UPDATE THIS FIELD NAME IF NECESSARY**
            doc_title = result.get('title', result.get('id', 'Untitled Document')) # <--- UPDATE THIS FIELD NAME IF NECESSARY

            documents.append({
                "title": doc_title,
                "content": doc_content,
                "score": result['@search.score']
            })
            print(f"  - Found document: '{doc_title}' (Score: {result['@search.score']:.2f})")
            if doc_content == 'No content found':
                print(f"    WARNING: Content for '{doc_title}' was not found. Check your index schema for the correct content field name.")
        return documents

# Initiate a chat between the user_proxy and the assistant.
# The user_proxy will start by asking a question that requires searching.
print("\n--- Starting Autogen Chat ---")
chat_result = user_proxy.initiate_chat(
    assistant,
    message="Summarize US tax resposibilities",
    # message="What is the capital of France?", # Example of a simple question
)

print("\n--- Autogen Chat Finished ---")
def fibonacci_series(n):
    """ Generate a Fibonacci series up to n elements. """
    if n < 0:
        raise ValueError("Number of terms must be non-negative")
    
    fib_series = []
    a, b = 0, 1
    for _ in range(n):
        fib_series.append(a)
        a, b = b, a + b

    return fib_series

def main():
    input_str = input("Enter the number of terms in the Fibonacci series you want: ")
    try:
        n = int(input_str)
        result = fibonacci_series(n)
        print("Fibonacci Series:", result)
    except ValueError as ve:
        print("Error:", ve)

if __name__ == "__main__":
    main()
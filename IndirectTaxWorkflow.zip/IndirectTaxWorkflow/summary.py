
"""
llm_summary.py

This module provides a function to generate a detailed summary of a large language model (LLM) response.
The detailed summary includes key points, examples, reasoning steps, assumptions, tone, structure, and areas for improvement.

Usage:
    from llm_summary import detailed_summary

    response = "Your LLM response here..."
    summary = detailed_summary(response)
    print(summary)
"""

import re

def detailed_summary(llm_response: str) -> dict:
    """
    Generate a detailed summary of an LLM response.

    Args:
        llm_response (str): The response from the LLM.

    Returns:
        dict: A dictionary containing the detailed summary.
    """
    key_points = []
    examples = []
    reasoning_steps = []
    assumptions = []
    tone = "neutral"
    structure = "paragraph"
    areas_for_improvement = []

    sentences = re.split(r'(?<=[.!?]) +', llm_response)

    for sentence in sentences:
        if "for example" in sentence.lower() or "e.g." in sentence.lower():
            examples.append(sentence)
        elif "because" in sentence.lower() or "therefore" in sentence.lower():
            reasoning_steps.append(sentence)
        elif "assume" in sentence.lower() or "assumption" in sentence.lower():
            assumptions.append(sentence)
        elif "please" in sentence.lower() or "note" in sentence.lower():
            tone = "polite"
        else:
            key_points.append(sentence)

    if len(sentences) == 1:
        structure = "single sentence"
    elif any(sentence.startswith("-") for sentence in sentences):
        structure = "list"

    summary = {
        'key_points': key_points,
        'examples': examples,
        'reasoning_steps': reasoning_steps,
        'assumptions': assumptions,
        'tone': tone,
        'structure': structure,
        'areas_for_improvement': areas_for_improvement
    }

    return summary

def main():
    response = (
        "The large language model (LLM) is a type of artificial intelligence that processes natural language. "
        "For example, OpenAI's GPT-3 is a popular LLM. It works by predicting the next word in a sentence based on the previous words. "
        "Because of this, it can generate coherent and contextually relevant text. However, it assumes that the input data is representative of the real world, which may not always be the case. "
        "Therefore, it is important to validate the output. Please note that this is a simplified explanation."
    )
    summary = detailed_summary(response)
    print(summary)

if __name__ == "__main__":
    main()
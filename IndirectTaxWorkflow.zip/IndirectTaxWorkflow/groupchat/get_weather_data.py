# filename: get_weather_data.py
import requests

# API request to get the weather data for Chennai
url = "https://api.openweathermap.org/data/2.5/weather"
params = {
    "q": "Chennai",
    "appid": "YOUR_API_KEY",
    "units": "metric"  # To get the temperature in Celsius
}

response = requests.get(url, params=params)
data = response.json()

# Extracting relevant weather information
weather_description = data['weather'][0]['description']
temperature = data['main']['temp']
humidity = data['main']['humidity']
wind_speed = data['wind']['speed']

# Printing the weather summary for Chennai
print(f"Weather in Chennai: {weather_description}")
print(f"Temperature: {temperature}°C")
print(f"Humidity: {humidity}%")
print(f"Wind Speed: {wind_speed} m/s")
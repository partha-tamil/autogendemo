# filename: sum_of_numbers.py
# Step 1: Ask the user to input the first number
num1 = float(input("Enter the first number: "))

# Step 2: Ask the user to input the second number
num2 = float(input("Enter the second number: "))

# Step 3: Calculate the sum of the two numbers
sum = num1 + num2

# Step 4: Print the sum
print("The sum of", num1, "and", num2, "is:", sum)